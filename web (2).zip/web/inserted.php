
<?php

$name =$_POST['user'];
$pas  =$_POST['psw'];
$rpas =$_POST['psw-repeat'];
$con =mysqli_connect("localhost","root","");

if(!$con)
{
    echo 'Not Connected ';
}

if(!mysqli_select_db($con,'law'))
{
    echo 'Error';
}

$sql ="INSERT INTO login (USER,PASS,RPASS) VALUES ('$name','$pas','$rpas')";


$redirect = false;
$redirect_page = ' main.html';
if(!mysqli_query($con,$sql))
{
   
print '<script typ="text/javascript" > ';
print 'alert("Failed")';
print '</script>';

}
else
{   

$redirect = true;
}

if($redirect==true)
{
    print '<script typ="text/javascript" > ';
print 'alert("THANKYOU TO REGISTER")';
print '</script>';
    header('Location:'.$redirect_page);
}
?>