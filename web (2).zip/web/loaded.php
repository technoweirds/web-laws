<?php

if (isset($_POST["user"]))
{
  $user = $_POST["user"];
  $pass = $_POST["pass"];

}
$redirect_page = 'lawmain.html';
if($user && $pass)
{
    $connect =mysqli_connect("localhost","root","","law")or die("could not find databse");
    $query=mysqli_query($connect,"SELECT * FROM login where USER='$user'");
    $numrows=mysqli_num_rows($query);
  	if($numrows!=0)
    {
        while($rows=mysqli_fetch_assoc($query))
        {
            $dbuser=$rows['USER'];
            $dbpas=$rows['PASS'];
            
            if($user==$dbuser && $pass==$dbpas)
            {
                print '<script>';
                print 'alert("WELCOME")';
                print '</script>';
                 header('Location:'.$redirect_page);
            }
        }
    }

}
 
?>
